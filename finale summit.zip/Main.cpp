#include <iostream>
#include <vector>
#include "Application.cpp"
#include "BookManager.cpp"
#include "BookAccount.cpp"

using namespace std;

int main() {

	Application app;
	//app.test();
	app.run();

	return 0;
}